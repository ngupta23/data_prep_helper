# "data-prep-helper" Package

This is a helper package for preparing and combining data from a variety of sourcesas described in the Overview section below. 

# Installation

```
pip install data-prep-helper
```

# Overview

This is a helper package for a variety of functions
1. Allows you to read data form a variety of sources 
    * A single csv file 
    * A single xls file
    * A folder containing multiple csv file
    * A weblink to a csv
    * A pandas dataframe
2. Allows you to specify multiple data sources.
3. Helper functions to clean the data
4. Helper functions to combine the data for final consumption

# Examples
Check out the  [examples](https://github.com/ngupta23/data-prep-helper/tree/master/examples) folder for details on usage

# Version History

## 0.0.1

* Initial Release

